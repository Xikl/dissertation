package com.ximo.springbootblogmaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBlogMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBlogMasterApplication.class, args);
	}
}
