package com.ximo.fileserver.constants;

/**
 * @author 朱文赵
 * @date 2018/5/16
 * @description
 */
public interface FileConstants {

    String ATTACHMENT = "attachment; filename=\"";


}
