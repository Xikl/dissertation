package com.ximo.fileserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMongodbFileServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMongodbFileServerApplication.class, args);
	}
}
